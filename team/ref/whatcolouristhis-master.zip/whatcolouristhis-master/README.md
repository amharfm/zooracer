# whatcolouristhis

#### About
whatcolouristhis is an eyedropper/colour picker written in Node.js. Drag and drop or paste your image on the page and click anywhere on it to retrieve the colour information. Try it out <a href="http://heyavery.github.io/whatcolouristhis/" target="_blank">here</a>.


#### Compatibility
Works best in Chrome. Firefox does not like custom inputs.


##### <a href="https://github.com/heyavery/whatcolouristhis/blob/master/LICENSE.md">MIT License</a>.
