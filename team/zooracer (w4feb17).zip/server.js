var http = require("http"),
	fs = require("fs"),
	ws = require("nodejs-websocket"),
	addr = require("address"),
	json = require("json-file");

var server = ws;
	server.IP = addr.ip() || "localhost";

var base = {
	"dir" : process.cwd(),
	"inc" : "geeky/js/"
};
const port = 7223;

process.stdout.write('\033c');
console.log("===================================");
console.log("Welkommen: Zoo Racer v1");
console.log("[web] http://"+server.IP+"/zooracer");
console.log("===================================");

server = ws.createServer(function (conn){
	conn.on("text", function(str){
//		console.log("\n ~"+(conn.uname || "?")+" : "+str);
		if (str){
			var obj = JSON.parse(str);
			switch (obj.to){
				case 'login' :
					console.log(conn.socket.remoteAddress, 'has joined, ok');
				break;
			}
		}
	})
	conn.on("close", function(code, reason){})
	conn.on("error", function(err){})
}).listen(port);
