var Player = {};

var WS = new WebSocket("ws://"+window.location.hostname+":7223");
	WS.onopen = function (){
		console.log('opopo');
		WS.send(JSON.stringify({
			to: 'login'
		}))
	};
	WS.onclose = function (){};
	WS.onerror = function (){};
	WS.onmessage = function (){};

var Game = {
	"hand":9090,
	'maxMovem' : 90,
	'send' : function(o){
		WS.send(JSON.stringify(o))
	},
	'login' : function() {
		var enteredName = prompt('Your name, mate?');
		if (enteredName=="" || enteredName.length<4){
			alert('Name must be at least 4 alpha/numeric characters');
			//cek current players
			this.login();
		} else {
			Player.name = enteredName;
			alert('Hello, '+Player.name);
			Game.send({
				'to': 'login', 'what': Player.name
			});
		}
	},
	'init' : function() {
		code.onkeyup = function(event){
			if(event.keyCode==13){
				run(25,true);
        		console.log("x", Turtle.x, "y", Turtle.y);
				code.value = '';
			}
		}
		code.focus();
		this.login();
	},
	'infront' : function(){
	},
	'eval' : function (code){
		code.split(' ').forEach(function(e){
			if(isFinite(e)){
				if (e<=Game.maxMovem) {
					run(25,true);
					code.value = '';
				} else {
					alert ('Max movement & degree is '+Game.maxMovem)
					code.value = '';
				}
			}
		})
	}
}
