#!/bin/bash
sudo node ./node_modules/nodemon/bin/nodemon.js ./server.js
