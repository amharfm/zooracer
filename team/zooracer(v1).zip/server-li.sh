#!/bin/bash
node ./server.js
