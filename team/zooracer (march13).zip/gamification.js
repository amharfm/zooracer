var Player = {};

var WS = new WebSocket("ws://"+window.location.hostname+":7223");
	WS.onopen = function (){};
	WS.onclose = function (e){};
	WS.onerror = function (err){};
	WS.onmessage = function (event){
		var obj = JSON.parse(event.data)
		console.log(obj);
		switch (obj.to){
			case 'login_ok':
				localStorage.setItem('name',obj.who);
				alert('Hello, '+obj.who);
				window.location.href = window.location.href + 'instructions.html';
				break;
			case 'yuk!' :
				localStorage.setItem('animal', obj.animal);
				window.animal = localStorage.getItem('animal');
				Game.ready(obj.animal);
				break;
			case 'animal is chosen':
				document.getElementById(obj.animal).parentNode.removeChild(document.getElementById(obj.animal));
				// Game.send({
				// 	'to': 'kuy!',
				// 	'who': localStorage.getItem('name'),
				// 	'anim': animal
				// });
				break;
			case 'ngioong' : 
				//bc
				for (var anim in obj.list){
					if(anim.animal!=window.location.hash.slice(1)){
						console.debug(anim.x, anim.y)
						
					}
					//@
				}

				run(25,true);
				Game.sense();
				code.value = '';

				break;
			case 'start' : 
				Game.start(obj.animal);
				break;
			case 'kuy!':
				Game.priiit(obj.animal);
				break;
			default :
				Game.okletsgo(obj.animal.slice(1));
				break;
		}
	};

var Game = {
	"hand":9090,
	'maxMovem' : 360,
	'send' : function(o){
		WS.send(JSON.stringify(o))
	},
	'sign' : function(){
		init('canvas','turtle','input','oldcode', 'textOutput'); clearcanvas(); run(1,true); 
		var wait = setInterval(function(){
			if (WS.readyState==1){
				clearInterval(wait);
				Game.send(location.hash);
			}
		}, 1000);
	},
	'okletsgo': function (animal){
		var em = document.getElementById('sprite');
            // em.id = 'sprite';
            // em.width = "20";
            // em.height = "20";
            em.style.position = "relative";
            em.src = "animals/"+animal+".ico";
        document.getElementById('turtle').appendChild(em);
	},
	'update_pos' : function(){

	},
	'join' : function(){
		Game.send({
			'to': 'join the race',
			'animal' : localStorage.getItem('animal')
		})
	},
	'priiit' : function (animal){
		console.info(obj, animal)
	},
	'start' : function (animal){
		window.location.href = window.location.origin+'/zooracer/race.html#'+animal;

		// Game.send({
		// 	'to': 'kuy!',
		// 	'animal' : animal,
		// 	'who': localStorage.getItem('name')
		// })

		// alert(animal);
		/*var em = document.createElement('embed');
            em.id = 'sprite';
            em.width = "20";
            em.height = "20";
            em.style.position = "relative";
            em.src = "animals/"+localStorage.animal+".ico";
            console.log(localStorage)
        document.getElementById('turtle').appendChild(em);*/

        /*var sp = document.createElement('div');
            sp.id = turtle_id;
        document.getElementsByClassName('inner')[1].appendChild(sp);
        */
	},
	'ready' : function(a){
		document.getElementById('animals').parentNode.removeChild(document.getElementById('animals'));
		document.getElementById('instruction').parentNode.removeChild(document.getElementById('instruction'))
		var centah = document.createElement('center');
			document.body.appendChild(centah);
		var pic = document.createElement('img');
			pic.setAttribute('id', 'sel_pl');
			pic.setAttribute('style', "align:'center';");
			pic.setAttribute('src', 'animals/'+animal+'.ico');
			centah.appendChild(pic);
			centah.appendChild(document.createElement('br'))
		var but_start = document.createElement('button');
			but_start.setAttribute('onclick', "Game.join()");
			but_start.innerHTML = 'START';
			centah.appendChild(but_start);
	},
	'choose_player' : function (i){
		if (confirm('Are you sure you choose '+i.id+'?')){
			Game.send({
				'to': 'choose player',
				'animal': i.id 
			})
		}
	},
	'login' : function() {
		if (document.getElementById('player_name')){
			var enteredName = document.getElementById('player_name').value;
			if (enteredName=="" || enteredName.length<4){
				alert('Name must be at least 4 alpha/numeric characters');
				//cek current players
				enteredName = '';
			} else {
				// Player.name = enteredName;
				Game.send({
					'to': 'login', 'what': enteredName
				});
			}
		}
		
	},
	'color' : {
		'track' : '#646464',
		'goal' : '#00cd06',
		'fence' : '#000000',
	},
	'sense' : function (){
		if (!step_detector){
			var step_detector = setInterval(function(){
				var color_now = canvasPixelColor({
					'x':parseFloat(turtle.turtle.x), 
					'y':parseFloat(turtle.turtle.y)}, 
					canvas.getContext('2d')
				);
				switch(color_now.hex){
					case Game.color.track :
						// console.info('ok')
						break;
					case Game.color.goal :
						clearInterval(step_detector);
						console.info(localStorage.getItem('name'), 'finishes the race!');
						alert('C O N G R A T U L A T I O N S!');
						document.getElementById('main').parentNode.removeChild(document.getElementById('main'))
						document.body.appendChild(document.createElement('div')).id = 'hurray'
						document.getElementById('hurray').innerHTML = "<h1>F I N I S H</h1>";
						document.getElementById('hurray').align = "center";
						break;
					case Game.color.fence :
						clearInterval(step_detector);
						console.error('Son!');
						alert('G A M E  O V E R');
						document.getElementById('main').parentNode.removeChild(document.getElementById('main'))
						window.location.href = window.location.origin + '/zooracer';
						break;
					default :
						console.log(color_now.hex)
						break;
				}
			}, 100)
		}
	},
	'init' : function() {
		code.onkeyup = function(event){
			if(event.keyCode==13){
				Game.send({
					'to': 'ngiuung',
					'who': localStorage.name,
					'anim' : window.location.hash.slice(1),
					'cmd' : code.value,
					'pos' : {
						'x': turtle.turtle.x,
						'y': turtle.turtle.y
					}
				})
			}
		}
		code.focus();
		this.login();
	},
	'eval' : function (code){
		code.split(' ').forEach(function(e){
			if(isFinite(e)){
				if (e<=Game.maxMovem) {
					run(25,true);
					code.value = '';
				} else {
					alert ('Max movement & degree is '+Game.maxMovem)
					code.value = '';
				}
			}
		})
	},
	'reset' : function (){
		if (localStorage.getItem('animal')) localStorage.removeItem('animal');
		if (localStorage.getItem('name')) localStorage.removeItem('name');
	}
}

Game.reset();