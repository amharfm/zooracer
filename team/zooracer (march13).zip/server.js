var http = require("http"),
	fs = require("fs"),
	ws = require("nodejs-websocket"),
	addr = require("address"),
	json = require("json-file"),
	canvasPixelColor = require("canvas-pixel-color");

var server = ws;
	server.IP = addr.ip() || "localhost";

var race = {};

var base = {
	"dir" : process.cwd(),
	"inc" : "geeky/js/"
};
const port = 7223;

var player_list = [];

process.stdout.write('\033c');
console.log("===================================");
console.log("Welkommen: Zoo Racer v1");
console.log("[web] http://"+server.IP+"/zooracer");
console.log("===================================");
var curr_pla;
			
server = ws.createServer(function (conn){
	conn.on("text", function(str){
//		console.log("\n ~"+(conn.uname || "?")+" : "+str);
		if (str){
			var obj = JSON.parse(str);
			console.log(obj)
			switch (obj.to){
				case 'login' :
					console.log(conn.socket.remoteAddress, 'has joined as',obj.what);
					curr_pla = String(conn.socket.remoteAddress);
					race[curr_pla] = {'x':250, 'y':250};
					conn.send(JSON.stringify({
						'to': 'login_ok',
						'who': obj.what
					}))
				break;
				case 'kuy!':
					conn.send(JSON.stringify({
						'to': 'kuy!',
						'who' : obj.who,
						'animal' : obj.animal
					}))
					break;
				case 'join the race' :
					conn.send(JSON.stringify({
						'to': 'start',
						'animal' : obj.animal
					}))
					// player_list.push(obj.animal);
					// player_list.push({
					// 	'animal':obj.animal,

					// });
					break;
				case 'choose player':
					console.log(conn.socket.remoteAddress, 'chooses', obj.animal)
					server.connections.forEach(function(e){
						e.send(JSON.stringify({
							'to': 'animal is chosen',
							'animal': obj.animal
						}))
					})
					race[conn.socket.remoteAddress]['animal'] = obj.animal;
					conn.send(JSON.stringify({
						'to': 'yuk!',
						'who' : obj.who,
						'animal' : obj.animal
					}))
					break;
				case 'ngiuung':
					race[curr_pla]['x'] = obj.pos.x;
					race[curr_pla]['y'] = obj.pos.y;
					//broadcast
					// server.connections.forEach(function(e){
						// e.send(JSON.stringify({
						conn.send(JSON.stringify({
							'to': 'ngioong',
							'who': obj.who,
							'anim': obj.anim,
							'cmd' : obj.cmd,
							'list': race
						}));
					// });
					break;
				case 'click_canvas':
					console.log(obj);
					// var qwe = canvasPixelColor(obj.ev, obj.ctx);
					// console.log(qwe)
					break;
				default :
					conn.send(JSON.stringify({
						'to': 'okletsgo',
						'animal': obj,
						'list': race
					}));
					break;
			}
			console.log(race);
		}
	})
	conn.on("close", function(code, reason){})
	conn.on("error", function(err){})
}).listen(port);
